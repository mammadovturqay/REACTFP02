export class MyColor {
  static colorOrange = "#FF922C";
  static colorGreen = "#54BF29";
  static colorBlack = "#333333";
  static colorWhite = "#FFFFFF";

  static colorLightOrange = "#F4E2D1";
  static colorLightGreen = "#DBF4D1";
}
